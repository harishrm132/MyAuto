Step 1: Create a Folder "C:\temp\IN"
Step 2: Place all drawings in "IN" folder
Step 3: Run "Mainbatch.bat" file
Step 4: Output PDF will be created in "C:\temp\OUT" folder